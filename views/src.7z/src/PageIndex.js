import React, {Component} from 'react'
import { BrowserRouter as Router, Route, Link} from 'react-router-dom'
import Home from './Pages/Home/Home'
import StudySmart from './Pages/Games/StudySmart'

import Header from "./Pages/Includes/Header"
import Footer from "./Pages/Includes/Footer"
import { Consumer } from "./Store/rootContext"

import User from './Pages/User/user'
// import Login from './Pages/User/login'
// import Logout from './Pages/User/logout'
// import Register from "./Pages/User/register"

class PageIndex extends Component{
    render(){
        return(
            <Router>
                <div>
                    {/* Show Area */}
                    <Header/>
                    <Consumer>
                        {(value)=>{
                            return <div>
                                <Route path="/" component={Home} exact />
                                <Route path="/web" component={Home} exact />
                                <Route path="/mobile" component={Home} exact />
                                <Route path="/Games/StudySmart_Play" component={StudySmart} />
                                <Route path="/user/:page" component={({match})=>{
                                    return <User context={value} match={match}/>
                                }} />
                            </div>
                        }}
                     </Consumer>
                    <Footer/>
                </div>
            </Router>
        );
    }
}

export default PageIndex;
                                /* {<Route path="/login" component={()=>{
                                    return <Login context={value} />
                                }} />
                                <Route path="/logout" component={()=>{
                                    return <Logout context={value}/>
                                }}/>
                                <Route path="/register" component={Register} />} */
