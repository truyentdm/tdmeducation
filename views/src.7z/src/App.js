import React,{Component} from "react"
import ReactDOM from "react-dom"
// import io from 'socket.io-client';
import PageIndex from './PageIndex'
import Panel from './Admin/Panel'
import {Provider,Consumer} from "./Store/rootContext"

// const socket = io("/my-namespace");
global.baseURL = __dirname//"./"
class App extends Component{
	constructor() {
		super()
		this.state = {
			pathname: location.pathname
		}
	}
	switch_screen(){
		const isScreenAdmin = this.state.pathname.substring(0,7) == "/panel/" || this.state.pathname == "/panel" || this.state.pathname == "/panel/";
		return isScreenAdmin ? <Panel/> : <PageIndex/>
	}
	render(){
		return(
		<Provider>
				{this.switch_screen()} 
		</Provider>);
	}
}
ReactDOM.render(<App/>,document.getElementById("root"));