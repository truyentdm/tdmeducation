import React,{ Component } from "react"
import Login from "./Components/login"
import Register from "./Components/register"
import Logout from "./Components/logout"
class User extends Component{
    constructor(props){
        super(props)
        console.log(props.match)
    }
    router(){
        var slug = this.props.match.params.page;
        if(slug == "login"){
            return <Login {...this.props}/>
        }else if(slug == "register"){
            return <Register {...this.props}/>
        }else if(slug == "logout"){
            return <Logout {...this.props}/>
        }else{
            window.location = "/user/login"
        }
    }
    render(){
        return (
            <React.Fragment>
                <div class="header-buffer"></div>
                {this.router()}
            </React.Fragment>
        );
    }
}

export default User