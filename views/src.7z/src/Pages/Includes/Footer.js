import React,{ Component } from 'react'
class Footer extends Component{
	render(){
		return(
			<div id="footer">
				<div id="footer_top">
					<p>TDM Education</p>
					<p>Số 298 đường Cầu Diễn, quận Bắc Từ Liêm, Hà Nội</p>
					<p>Email: truyentdm@gmail.com</p>
				</div>
				<div id="footer_bottom">
					<p>Copyright © 2018 TDM SOFTWARE .</p>
				</div>
			
			</div>
		);
	}
}
export default Footer;