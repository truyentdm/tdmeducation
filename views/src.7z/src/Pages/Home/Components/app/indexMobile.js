import React,{ Component } from 'react'

class IndexMobile extends Component{
	render(){
		return(
			<div>
                Ứng dụng mobile đang được xây dựng, vui lòng quay lại sau
            </div>
		);
	}
}
export default IndexMobile;