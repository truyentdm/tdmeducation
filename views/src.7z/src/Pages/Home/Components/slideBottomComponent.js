import React,{Component} from "react"

class SlideBottom extends Component{
    render(){
        return(
            <section class="regis content_logo">
            <ul class="list_proud slick-initialized slick-slider slick-dotted"><button class="slick-prev slick-arrow slick-disabled" aria-label="Previous" type="button" aria-disabled="true" style={{"display": "block"}}>Previous</button>

                <div class="slick-list draggable">
                    <div class="slick-track" tabindex="1" style={{"opacity": 1, "width": "2698px", "transform": "translate3d(0px, 0px, 0px)"}}><li class="slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" role="tabpanel" id="slick-slide10" aria-describedby="slick-slide-control10" style={{"width": "1349px"}}>

                    <div class="content_reg col1200 ">

                        <div class="clearfix">
                        
							<div class="f30 clwhite " style={{"text-align":"left"}}><strong class=""> ĐỐI TÁC TDM </strong>&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; <strong class=""> OTHER</strong></div>
                            
                                <div class="slide_pround">
    
                                    <div class="mb_logo"><img draggable="false"src="http://faptvmedia.com/images/icon/icon_pround_1.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_2.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_3.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_4.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_5.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_6.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_7.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_8.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_9.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/icon_pround_10.png"/> </div>
    
                                </div>

                        </div>

                    </div>

                    <div class="bg_case_study"></div>

                </li><li class="slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" role="tabpanel" id="slick-slide11" aria-describedby="slick-slide-control11" style={{"width": "1349px"}}>

                    <div class="content_reg col1200 ">

                        <div class="clearfix">

							<div class="f30 clwhite " style={{"text-align":"left"}}><strong class=""> ĐỐI TÁC TDM </strong>&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; <strong class=""> GAMING</strong></div>
                            
                                <div class="slide_pround slide_pround_game">
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team1.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team2.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team3.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team4.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team5.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team6.png"/> </div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team7.png"/></div>
    
                                    <div class="mb_logo"><img src="http://faptvmedia.com/images/icon/team8.png"/> </div>
    
                                </div>

                        </div>

                    </div>

                    <div class="bg_case_study" style={{"background-image":"url(http://faptvmedia.com/images/bg_logo2.jpg)"}}></div>

                </li></div></div>

                

            <button class="slick-next slick-arrow" aria-label="Next" type="button" style={{"display": "block"}} aria-disabled="false">Next</button><ul class="slick-dots" style={{"display": "block"}} role="tablist"><li class="slick-active" role="presentation"><button type="button" role="tab" id="slick-slide-control10" aria-controls="slick-slide10" aria-label="1 of 2" tabindex="0" aria-selected="true">1</button></li><li role="presentation" class=""><button type="button" role="tab" id="slick-slide-control11" aria-controls="slick-slide11" aria-label="2 of 2" tabindex="-1">2</button></li></ul></ul>

            <div class="bg_top_reg"></div>

            <div class="bg_bottom_reg"></div>

        </section>
        );
    }
}
export default SlideBottom;