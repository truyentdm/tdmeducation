import React,{ Component } from 'react'

class IndexPublish extends Component{
	render(){
		return(
			<div>
                Cộng động đang được xây dựng, vui lòng quay lại sau
            </div>
		);
	}
}
export default IndexPublish;