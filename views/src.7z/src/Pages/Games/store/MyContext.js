import React,{Component} from "react"
import queue from '../data/queue'

const MyContext = React.createContext();
export class Provider extends Component {
    state = {
        popupShow: false,
        playing: false,
        store: new queue(),
        data: null,
        count: 0,
        isNext: false,
        flag: false,
        user_input: "",
        message: ""
    }
    setShowPopup = (data)=>{
        this.setState({ popupShow : data})
    }
    setPlaying =(data)=>{
        this.setState({playing: data});
    }
    setCount =(data)=>{
        this.setState({count: data});   
    }
    setNext =(data)=>{
        this.setState({isNext: data});   
    }
    setData = (data)=>{
        this.setState({data:data})
    }
    setTypeOfGame = (data)=>{
        this.setState({typeofgame: data})
    }
    updateInput = (data)=>{
        this.setState({user_input: data})
    }
    updateData = (list)=>{
        console.log("MyContext",list)
        this.setCount(list.length)
        this.state.store.clear();
        for(let i=0;i< list.length;i++){
            this.state.store.enqueue(list[i])
        }
    }
    startPlaying = ()=>{
        this.setData(this.state.store.peek());
        this.setPlaying(true);
    }
    checkAnswer = (data)=>{
        this.setNext(true);
        this.state.store.dequeue();
        const book_word = data.trim().toLowerCase();
        const user_word = this.state.user_input.toString().trim().toLowerCase();
        if(user_word.localeCompare(book_word) == 0){
            console.log("Chính xác")
        }else{
            console.log("Không chính xác")
        }
    }
    nextPlaying = ()=>{
        this.updateInput("");
        this.setNext(false);
        this.setCount(this.state.store.count());
        this.setData(this.state.store.peek())
    }
    render(){
        return (
            <MyContext.Provider value={{
                state: this.state,
                action: {
                    setShowPopup: this.setShowPopup,
                    setPlaying: this.setPlaying,
                    setCount: this.setCount,
                    updateData: this.updateData,
                    startPlaying: this.startPlaying,
                    checkAnswer: this.checkAnswer,
                    nextPlaying: this.nextPlaying,
                    updateInput: this.updateInput
                }
            }}>
                {this.props.children}
            </MyContext.Provider>
        );
    }
}

export const Consumer = MyContext.Consumer;