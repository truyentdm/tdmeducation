import React,{Component} from 'react'
import {Consumer} from "../store/MyContext"
import reponseServer from "../../../utility/reponseServer"
class MainComponent extends Component{
    addTypeOfGame = (data)=>{
        let listItem = typeof data == "object" ? data : [];
        for(let i=0;i<listItem.length;i++){
            listItem[i].type = Math.floor((Math.random() * 2) + 1);
        }
        return listItem;
    }
	render(){
		return (
			<div class="wp_play_game">
                <p>Số từ đã học hôm nay: <b>10</b></p>
                <p>Số từ đã ôn lại hôm nay: <b>10</b></p>
                <table width="100%" class="tab_object">
                    <thead>
                        <th>Gói 3000 Từ vựng</th>
                        <Consumer>
                            {(value)=>{
                                const {playing} = value.state;
                                const {setShowPopup, updateData} = value.action;
                                return <th><button onClick={()=>{
                                    if(!playing){
                                        reponseServer("english/store",{},"POST")
                                        .then(res=>{
                                            updateData(this.addTypeOfGame(res.data));
                                        })
                                    }
                                    setShowPopup(true);
                                }}>{playing? "Chơi tiếp":"Luyện tập"}</button></th>
                            }}
                        </Consumer>
                    </thead>
                </table>
            </div>
        );
	}
}

export default MainComponent;