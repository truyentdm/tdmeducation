import React,{Component} from "react"
import {Consumer} from "../../store/MyContext"

class ButtonPlayingComponent extends Component{
    render(){
        return(
            <Consumer>
                {(value=>{
                    const {isNext,data} = value.state
                    const {checkAnswer,nextPlaying} = value.action
                    return(
                        <div id="media_control">
                            <div class="media_desc_point clearfix">
                                <div class="d1">
                                    {isNext && "Điểm từ vựng là 30"}
                                </div>
                                <div class="d1">
                                    <input type="button" class="btn_white"
                                        value={isNext ? "Học tiếp" : "Xác nhận"} 
                                        onClick = {()=>{
                                            if(isNext){
                                                nextPlaying()
                                            }else{
                                                checkAnswer(data.wordbook["en"])
                                            }
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                    );
                })}
            </Consumer>
        );
    }
}
export default ButtonPlayingComponent;