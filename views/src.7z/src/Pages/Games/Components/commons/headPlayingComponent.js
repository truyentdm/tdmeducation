import React,{Component} from "react"
import {Consumer} from "../../store/MyContext"
class HeadPlayingComponent extends Component{
    constructor(props){
        super(props);
    }
    state = {
        image: false,
        playAudio: false,
        world: false,
        translate: false
    }
    componentDidMount(){
        switch(this.props.type){
            case 0:
                break;
            case 1:
                this.setState({
                    image: true,
                    playAudio: true,
                    world: false,
                    translate: false
                })
                break;
            case 2:
                this.setState({
                    image: false,
                    playAudio: false,
                    world: false,
                    translate: true
                })
                break;
            default:
        }
    }
    
    render(){
        return(
            <Consumer>
                {(value)=>{
                    const {isNext,data,flag} = value.state;

                    return (
                        <div class="media_section clearfix">
                            <div class="s1">
                                <span class="media_img_desc">
                                    {(this.state.image || isNext) && <img src="../../imgs/games/child.jpg" alt="" draggable="false"/>}
                                </span>
                            </div>
                            <div class="s1">
                                <span class="playAudio">
                                    {(this.state.playAudio || isNext) && <i class="volume-small volume-small fa fa-volume-up" aria-hidden="true"></i>}
                                </span>
                                <span class="audio_word">
                                    { (isNext || this.state.world) && data.wordbook["en"]}
                                    { (!isNext && this.state.translate) && data.wordbook["vi"]}
                                </span>
                                <span class="audio_pa">
                                    { isNext && data.pronunciation["en"]}
                                </span>
                                {
                                    //Detail Word
                                    (!flag && isNext) && <div class="audio_intro">
                                            <i class="fa fa-book" aria-hidden="true"></i>
                                            <h3>Thông tin từ</h3>
                                        </div>
                                }
                                
                            </div>
                            <div class="s1">
                                <span class="media_conf">
                                    <i class="fa fa-cog" aria-hidden="true"></i>
                                </span>
                            </div>
                        </div>
                    );
                }}
            </Consumer>
        );
    }
}
export default HeadPlayingComponent;