import React,{Component} from 'react'
import {Consumer} from '../../store/MyContext'

class StartComponent extends Component{
	state = {
		isLoading: true,
		isReadly: false
	}

	componentDidMount = ()=>{
		setTimeout(function() { this.setState({isLoading: false}); }.bind(this), 500);
	}
	render(){
		return (
			<div>
				{this.state.isLoading ? (
						<div class="wp_center_icon">
							<img src="/imgs/games/load_ico.png" class="load_icon"/>
							<div>Load data</div>
						</div>
					) : (
						<div class="game_list_msg">
								<div class="clearfix">
									<div class="sys_icon fl_left">System</div>
									<div class="sys_msg fl_left">
										<span>Có 15 từ cần ghi nhớ để vượt qua ván chơi</span><br/>
										<span>Có 150 từ đã học cần ôn lại</span><br/>
										<span>Còn 10 từ mới cần học để đạt mục tiêu mỗi ngày</span><br/>
									</div>	
								</div>
								<Consumer>
									{(value)=>{
										const {startPlaying} = value.action;
										return this.state.isReadly ? (
											 <div class="clearfix">
												<div class="me_msg fl_right">
													<span>Sẵn sàng</span>
												</div>	
											</div>
										) : (
											<button class="button_game_play" onClick={()=>{
												this.setState({isReadly: true});
												setTimeout(()=>{
													startPlaying();
												},1000)
											}}>Sẵn sàng</button>
										)
									}}
								</Consumer>
						</div>
				)}						
			</div>
		);
	}
}

export default StartComponent;