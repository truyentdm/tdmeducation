import React,{Component} from 'react'

class EndComponent extends Component{
	render(){
		return (<div>End Game</div>);
	}
}

export default EndComponent;