import React,{Component} from "react"
import Header from "./Includes/Header"
import Footer from "./Includes/Footer"
import PageIndex from "./PageIndex"
import "./Styles/layout.css"
import { Consumer } from "../Store/rootContext"
import $ from "jquery"
class Pannel extends Component{
    passport(value){
        const action = value.action;
        action.isAuthenticated((data)=>{
            if(!data){
                location = "/user/login"
            }
        })
    }
    componentDidMount(){
    }
    render(){
        return (
            <div id="admin">
                <Consumer>
                {(value)=>{
                    this.passport(value)
                }}
                </Consumer>
                <Header/>
                <PageIndex/>
                {/* <Footer/> */}
            </div>
        );
    }
}
export default Pannel