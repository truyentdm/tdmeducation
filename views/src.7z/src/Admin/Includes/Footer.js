import React,{Component } from "react"
class Footer extends Component{
    render(){
        return (
            <div id="footer">
                <p>
                    2018 by TDM Group
                </p>
            </div>
        );
    }
}
export default Footer