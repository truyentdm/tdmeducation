import React,{Component} from "react"
class Views extends Component{
    render(){
        return (
            <React.Fragment>
                <ul class="content-menu">
                    <li>
                        <a href="/panel"><i class="fa fa-home" aria-hidden="true"></i> Trang chủ</a>
                    </li>
                    <li>
                        <a href="#">Trang</a>
                    </li>
                    
                </ul>
                <ul class="head-menu">
                    <li>
                        <h1>Danh sách dữ liệu</h1>
                    </li>
                    <li>
                        <a href="#" class="add">Thêm mới</a>
                    </li>
                </ul>
                <div class="tbl-view">
                    <table>
                        <thead>
                            <tr>
                                <th><input type="checkbox"/></th>
                                <th>TT</th>
                                <th colspan="2">Word English</th>
                                <th>Từ tiếng việt</th>
                                <th>Pronunciation</th>
                                <th>audio</th>
                                <th>Action</th>
                                <th>Ngày</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><input type="checkbox"/></td>
                                <td>1</td>
                                <td>truyentdm</td>
                                <td></td>
                                <td>Duong Minh Truyen</td>
                                <td>truyentdm@dmainl.com</td>
                                <td>098352999</td>
                                <td>Admin</td>
                                <td>12-7-2016</td>
                            </tr>
                            <tr>
                                <td><input type="checkbox"/></td>
                                <td>1</td>
                                <td>truyentdm</td>
                                <td></td>
                                <td>Duong Minh Truyen</td>
                                <td>truyentdm@dmainl.com</td>
                                <td>098352999</td>
                                <td>Admin</td>
                                <td>12-7-2016</td>
                            </tr>
                            <tr>
                                <td><input type="checkbox"/></td>
                                <td>1</td>
                                <td>truyentdm</td>
                                <td></td>
                                <td>Duong Minh Truyen</td>
                                <td>truyentdm@dmainl.com</td>
                                <td>098352999</td>
                                <td>Admin</td>
                                <td>12-7-2016</td>
                            </tr>
                            <tr>
                                <td><input type="checkbox"/></td>
                                <td>1</td>
                                <td>truyentdm</td>
                                <td></td>
                                <td>Duong Minh Truyen</td>
                                <td>truyentdm@dmainl.com</td>
                                <td>098352999</td>
                                <td>Admin</td>
                                <td>12-7-2016</td>
                            </tr>
                            <tr>
                                <td><input type="checkbox"/></td>
                                <td>1</td>
                                <td>truyentdm</td>
                                <td></td>
                                <td>Duong Minh Truyen</td>
                                <td>truyentdm@dmainl.com</td>
                                <td>098352999</td>
                                <td>Admin</td>
                                <td>12-7-2016</td>
                            </tr>
                        
                        </tbody>
                    </table>
                    <ul class="dl-control">
                        <li>
                            Trang 
                            <input type="button" value="<"/>
                            <input type="text" value="2"/>
                            <input type="button" value=">"/>
                            trên 10
                            &nbsp;&nbsp;|&nbsp;&nbsp;
                        </li>
                        <li>
                            xem
                            <select>
                                <option value="10">10</option>
                            </select>
                            bản ghi
                            &nbsp;&nbsp;|&nbsp;&nbsp;
                        </li>
                        <li>Tổng 198 bản ghi</li>
                    </ul>
                </div>
            </React.Fragment>
        );
    }
}

export default Views