import React,{Component} from "react"
import "../../Styles/ae.css"
import ExampleComponent from "../Common/exampleComponent"
import axios from "axios"
class AE extends Component{
    state = {
        totalExample: 1,
        wordbook: {
            en: "",
            vi: ""
        },
        audio: {
            en: "",
            vi: ""
        },
        pronunciation: {
            en: "",
            vi: ""
        },
        example: {
            en : [],
            other: []
        },
        message: ""

    }
    handChange = (event)=>{
        const target = event.target;
        const lang = target.lang
        const name = target.name
        const value = target.type == "checkbox" ? target.checked : target.value
        this.setState({
            [name]: {
                ...this.state[name],
                [lang]: value
            }
        })
    }
    handleChangeExample = (event)=>{
        const name = event.target.name
        const lang = event.target.lang
        const position = event.target.getAttribute("position")
        const value = event.target.value
        var data = this.state.example[lang] == undefined ? [] : [...this.state.example[lang]]
        data[position] = this.state.example[lang] == undefined ? {
            [name] : value
        } : {
            ...this.state.example[lang][position],
            [name] : value
        }
        
        this.setState({
            example: {
                ...this.state.example,
                [lang] : data
            }
        })

    }
    handSubmit = (event)=>{
        event.preventDefault();
        var data = {
            wordbook: this.state.wordbook,
            audio:this.state.audio,
            example: this.state.example,
            pronunciation: this.state.pronunciation,

        }
        if(this.isEmptyError()){
            axios({
                url: "/english/api_insert",
                method: "post",
                data: data
            })
            .then(result=>{
                console.log(result.data)
            })
            .catch(e=>{
                console.log(e.toString())
            })
        }else{
           
        }
        console.log(this.state)
    }
    isEmptyError = ()=>{
        if(this.state.wordbook["en"] == "" || this.state.wordbook["en"] == undefined || this.state.wordbook["en"] == null){
            this.setState({
                message: "Word book không được để trống"
            })
            return false
        }else{
            this.setState({
                message: ""
            })
            return true
        }
    }
    renderExample(lang){
        var element = []
        for(var i = 0;i<this.state.totalExample;i++){
            element.push(<ExampleComponent lang={lang} key={i} index={i} onChangeExample= {this.handleChangeExample}/>)
        }
        return element;
    }
    upExample(){
        this.setState({
            totalExample: this.state.totalExample+1
        })
    }
    downExample(){
        var current = this.state.totalExample <= 0 ? 0 : this.state.totalExample-1
        this.setState({
            totalExample: current
        })
    }
    render(){
        return (
            <React.Fragment>
                <div id="ae">
                    <form>
                    <table cellSpacing="0">
                        <thead>
                            <tr>
                                <th colSpan="3" align="left">Thêm mới</th>   
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Key</td>
                                <td>English</td>
                                <td>
                                    <select>
                                        <option value="vi">Việt Nam</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Word book</td>
                                <td><input type="text" name="wordbook" lang="en" onChange={this.handChange}/></td>
                                <td>
                                    <input type="text" name="wordbook" lang="vi" onChange={this.handChange}/>
                                </td>
                            </tr>
                            <tr>
                                <td>audio</td>
                                <td><input type="text" name="audio" lang="en" onChange={this.handChange}/></td>
                                <td>
                                    <input type="text" name="audio" lang="vi" onChange={this.handChange}/>
                                </td>
                            </tr>
                            <tr>
                                <td>pronunciation</td>
                                <td><input type="text" name="pronunciation" lang="en" onChange={this.handChange}/></td>
                                <td>
                                    <input type="text" name="pronunciation" lang="vi" onChange={this.handChange}/>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Example
                                    <div class="add_plus" onClick={this.upExample.bind(this)}><i class="fas fa-plus-square"></i></div>
                                    <div class="add_plus" onClick={this.downExample.bind(this)}><i class="fas fa-minus-square"></i></div>
                                </td>
                                <td>
                                    {this.renderExample("en")}
                                </td>
                                <td>
                                    {this.renderExample("vi")}
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td colspan="2" align="left" class="message_error">
                                    {this.state.message}
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td colspan="2" align="left">
                                    <input type="button" value="Lưu" class="btn_primary" onClick={this.handSubmit}/>
                                    &nbsp;&nbsp;
                                    <input type="button" value="Hủy" class="btn_white" onClick={()=>{
                                        location = "/panel/StudySmart/view"
                                    }}/>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    </form>
                </div>
            </React.Fragment>
        );
    }
}

export default AE